#include "Includes.h"
#pragma once

void SetBackgroundImage(QString qs, QMainWindow& window);

